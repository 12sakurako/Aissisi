
import discord
from discord import app_commands
import json

# ボットの設定
intents = discord.Intents.default()
intents.members = True
intents.message_content = True
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# 設定ファイルを保存/読み込みするためのファイル
CONFIG_FILE = 'config.json'

# 設定を保存する関数
def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=4)

# 設定を読み込む関数
def load_config():
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# ボット起動時に呼ばれる
@client.event
async def on_ready():
    print(f'{client.user} がオンラインになりました！')
    await tree.sync()  # スラッシュコマンドを同期

# 認証用のメッセージとボタンを送信するコマンド
@tree.command(name="setup", description="認証システムをセットアップします")
@app_commands.checks.has_permissions(administrator=True)
async def setup_verification(interaction: discord.Interaction, role: discord.Role):
    # 設定を読み込み
    config = load_config()
    guild_id = str(interaction.guild_id)

    # 設定を更新
    config[guild_id] = {
        'role_id': role.id,
        'channel_id': interaction.channel_id
    }
    save_config(config)

    # 認証用の埋め込みメッセージ
    embed = discord.Embed(
        title="認証",
        description="以下のボタンをクリックしてロールを獲得してください！",
        color=discord.Color.blue()
    )

    # ボタンの作成
    view = VerificationView(role.id)
    await interaction.response.send_message(embed=embed, view=view)

# ボタンのクラス
class VerificationView(discord.ui.View):
    def __init__(self, role_id):
        super().__init__(timeout=None)
        self.role_id = role_id

    @discord.ui.button(label="認証", style=discord.ButtonStyle.green, custom_id="verify_button")
    async def verify_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(self.role_id)
        if role is None:
            await interaction.response.send_message("ロールが見つかりません。管理者に連絡してください。", ephemeral=True)
            return

        # ロールがすでに付与されているかチェック
        if role in interaction.user.roles:
            await interaction.response.send_message("すでに認証済みです！", ephemeral=True)
        else:
            await interaction.user.add_roles(role)
            await interaction.response.send_message(f"{role.name} ロールを付与しました！", ephemeral=True)

# エラーハンドリング
@setup_verification.error
async def setup_verification_error(interaction: discord.Interaction, error):
    if isinstance(error, app_commands.errors.MissingPermissions):
        await interaction.response.send_message("このコマンドを使用するには管理者権限が必要です。", ephemeral=True)

# チケットシステム用のボタンビュー
class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="チケットを作成", style=discord.ButtonStyle.green, custom_id="create_ticket")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # チケットカテゴリーを取得
        config = load_config()
        guild_id = str(interaction.guild_id)
        if guild_id not in config or 'ticket_category' not in config[guild_id]:
            await interaction.response.send_message("チケットカテゴリーが設定されていません。", ephemeral=True)
            return

        category_id = config[guild_id]['ticket_category']
        category = interaction.guild.get_channel(category_id)
        
        # チケットチャンネルを作成
        channel_name = f"ticket-{interaction.user.name}"
        channel = await interaction.guild.create_text_channel(
            name=channel_name,
            category=category,
            overwrites={
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
            }
        )

        # 削除ボタンを含むメッセージを送信
        embed = discord.Embed(
            title="チケット",
            description="サポートをご利用いただきありがとうございます。\n下のボタンでチケットを閉じることができます。",
            color=discord.Color.blue()
        )
        
        delete_view = TicketDeleteView()
        await channel.send(embed=embed, view=delete_view)
        await interaction.response.send_message(f"チケットを作成しました: {channel.mention}", ephemeral=True)

class TicketDeleteView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="チケットを閉じる", style=discord.ButtonStyle.red, custom_id="close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.channel.delete()

@tree.command(name="ticket", description="チケットシステムをセットアップします")
@app_commands.checks.has_permissions(administrator=True)
async def setup_ticket(interaction: discord.Interaction, category: discord.CategoryChannel):
    # 設定を保存
    config = load_config()
    guild_id = str(interaction.guild_id)
    if guild_id not in config:
        config[guild_id] = {}
    
    config[guild_id]['ticket_category'] = category.id
    save_config(config)

    # チケット作成用の埋め込みメッセージを送信
    embed = discord.Embed(
        title="チケットシステム",
        description="下のボタンをクリックしてチケットを作成してください。",
        color=discord.Color.blue()
    )

    view = TicketView()
    await interaction.response.send_message(embed=embed, view=view)

@setup_ticket.error
async def setup_ticket_error(interaction: discord.Interaction, error):
    if isinstance(error, app_commands.errors.MissingPermissions):
        await interaction.response.send_message("このコマンドを使用するには管理者権限が必要です。", ephemeral=True)

# 実績記入用のボタンビュー
class AchievementView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="実績を記入", style=discord.ButtonStyle.primary, custom_id="log_achievement")
    async def log_achievement(self, interaction: discord.Interaction, button: discord.ui.Button):
        # モーダルを表示
        await interaction.response.send_modal(AchievementModal())

# 実績記入用のモーダル
class AchievementModal(discord.ui.Modal, title='実績記入'):
    achievement = discord.ui.TextInput(
        label='実績内容',
        style=discord.TextStyle.paragraph,
        placeholder='実績の内容を入力してください',
        required=True,
        max_length=1000
    )

    async def on_submit(self, interaction: discord.Interaction):
        config = load_config()
        guild_id = str(interaction.guild_id)
        
        if guild_id not in config or 'achievement_channel' not in config[guild_id]:
            await interaction.response.send_message("実績チャンネルが設定されていません。", ephemeral=True)
            return

        channel_id = config[guild_id]['achievement_channel']
        channel = interaction.guild.get_channel(channel_id)

        embed = discord.Embed(
            title="新しい実績",
            description=str(self.achievement),
            color=discord.Color.green(),
            timestamp=discord.utils.utcnow()
        )
        embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.avatar.url if interaction.user.avatar else None)
        
        await channel.send(embed=embed)
        await interaction.response.send_message("実績を記録しました！", ephemeral=True)

@tree.command(name="achievement_setup", description="実績記入システムをセットアップします")
@app_commands.checks.has_permissions(administrator=True)
async def setup_achievement(interaction: discord.Interaction, channel: discord.TextChannel):
    # 設定を保存
    config = load_config()
    guild_id = str(interaction.guild_id)
    if guild_id not in config:
        config[guild_id] = {}
    
    config[guild_id]['achievement_channel'] = channel.id
    save_config(config)

    # 実績記入用の埋め込みメッセージを送信
    embed = discord.Embed(
        title="実績記入システム",
        description="下のボタンをクリックして実績を記入してください。",
        color=discord.Color.blue()
    )

    view = AchievementView()
    await interaction.response.send_message(embed=embed, view=view)

@setup_achievement.error
async def setup_achievement_error(interaction: discord.Interaction, error):
    if isinstance(error, app_commands.errors.MissingPermissions):
        await interaction.response.send_message("このコマンドを使用するには管理者権限が必要です。", ephemeral=True)

client.run('MTM3MzU3Njc0OTUzMDYxNTgxOA.GKQAB_.EXNVbQ5rTmomaG1Nd0LutYGhL_zKlxme1aAIpE')
